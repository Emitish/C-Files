997279300, Emily Sison
Line 222-225: Added 4 more "includes"
Line 248-249: Initialize the structs for reading and writing
Line 1029-1030: Added 2 more Global vfs data structures
Line 1035-1046: Create struct for reading
Line 1049-1060: Create struct for writing


